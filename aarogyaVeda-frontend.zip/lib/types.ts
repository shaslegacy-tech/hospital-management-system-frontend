export type Role = "ADMIN" | "DOCTOR" | "PATIENT" | "RECEPTIONIST" | "SUPER_ADMIN";

export type AppointmentStatus =
  | "PENDING"
  | "CONFIRMED"
  | "COMPLETED"
  | "CANCELLED";

export type BillStatus = "PENDING" | "PAID" | "CANCELLED";

export interface AuthResponse {
  token: string;
  userId: number;
  name: string;
  email: string;
  phone: string;
  role: Role;
  hospitalStatus: string | null;
}

export interface DepartmentResponse {
  id: number;
  name: string;
  description: string;
  active: boolean;
  createdAt: string;
}

export interface DoctorResponse {
  id: number;
  userId: number;
  doctorName: string;
  email: string;
  phone: string;
  departmentId: number;
  departmentName: string;
  specialization: string;
  experienceYears: number;
  consultationFee: number;
  bio: string;
  available: boolean;
  workStartTime: string;
  workEndTime: string;
  slotDurationMinutes: number;
  averageRating: number | null;
  reviewCount: number;
  gender: string | null;
  createdAt: string;
}

export interface PatientResponse {
  id: number;
  userId: number;
  patientName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  bloodGroup: string;
  address: string;
  emergencyContact: string;
  emergencyContactName: string;
  medicalHistory: string;
  createdAt: string;
}

export interface AppointmentResponse {
  id: number;
  patientId: number;
  patientName: string;
  doctorId: number;
  doctorName: string;
  departmentName: string;
  appointmentDate: string;
  appointmentTime: string;
  status: AppointmentStatus;
  reason: string;
  notes: string | null;
  amount: number;
  createdAt: string;
}

export interface PrescriptionResponse {
  id: number;
  medicineName: string;
  dosage: string;
  duration: string;
  instructions: string;
  createdAt: string;
}

export interface MedicalRecordResponse {
  id: number;
  appointmentId: number;
  patientName: string;
  doctorName: string;
  diagnosis: string;
  treatment: string;
  notes: string;
  prescriptions: PrescriptionResponse[];
  createdAt: string;
  patientSummary: string | null;
}

export interface BillResponse {
  id: number;
  appointmentId: number;
  patientName: string;
  doctorName: string;
  departmentName: string;
  consultationFee: number;
  additionalCharges: number;
  totalAmount: number;
  status: BillStatus;
  paymentMethod: string | null;
  notes: string;
  createdAt: string;
}

export interface PatientFileResponse {
  id: number;
  patientId: number;
  patientName: string;
  originalFileName: string;
  fileType: string;
  contentType: string;
  fileSize: number;
  description: string;
  downloadUrl: string;
  createdAt: string;
}

export interface Page<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  number: number;
  size: number;
  first: boolean;
  last: boolean;
}

// ---------- Doctor portal request types ----------
export interface MedicalRecordRequest {
  appointmentId: number;
  diagnosis: string;
  treatment: string;
  notes?: string;
}

export interface PrescriptionRequest {
  medicalRecordId: number;
  medicineName: string;
  dosage: string;
  duration: string;
  instructions?: string;
}

// ---------- Admin portal types ----------
export interface DashboardResponse {
  totalDoctors: number;
  totalPatients: number;
  totalDepartments: number;
  totalAppointments: number;
  pendingAppointments: number;
  confirmedAppointments: number;
  completedAppointments: number;
  cancelledAppointments: number;
  totalRevenue: number;
  pendingBillsCount: number;
  pendingBillsAmount: number;
}

export interface DepartmentRequest {
  name: string;
  description: string;
  active?: boolean;
}

export interface DoctorRequest {
  userId: number;
  departmentId: number;
  specialization: string;
  experienceYears: number;
  consultationFee: number;
  bio?: string;
  available?: boolean;
  workStartTime?: string;
  workEndTime?: string;
  slotDurationMinutes?: number;
  gender?: string;
}

export interface DoctorOnboardRequest {
  name: string;
  email: string;
  password: string;
  phone: string;
  departmentId: number;
  specialization: string;
  experienceYears: number;
  consultationFee: number;
  gender?: string;
  bio?: string;
  workStartTime?: string;
  workEndTime?: string;
  slotDurationMinutes?: number;
}

export interface UserSummary {
  id: number;
  name: string;
  email: string;
  role: Role;
}

export interface PatientRequest {
  userId: number;
  dateOfBirth: string;
  bloodGroup: string;
  address: string;
  emergencyContact: string;
  emergencyContactName: string;
  medicalHistory?: string;
}

export interface BillRequest {
  appointmentId: number;
  additionalCharges?: number;
  notes?: string;
}

export interface PaymentOrder {
  orderId: string;
  amountInPaise: number;
  currency: string;
  keyId: string;
  billId: number;
}

export interface ReviewItem {
  id: number;
  appointmentId: number;
  patientName: string;
  doctorId: number;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface NotificationItem {
  id: number;
  message: string;
  type: string;
  link: string | null;
  isRead: boolean;
  createdAt: string;
}

export interface SymptomCheckResult {
  departmentId: number | null;
  departmentName: string;
  explanation: string;
  urgencyLevel: "LOW" | "MEDIUM" | "HIGH";
  disclaimer: string;
}

export interface ClinicalNotesDraft {
  diagnosis: string;
  treatment: string;
  notice: string;
}

export interface InsightMessage {
  role: "user" | "assistant";
  content: string;
}

export interface AuditLogItem {
  id: number;
  userName: string;
  userRole: string | null;
  action: string;
  entityType: string;
  entityId: number;
  details: string;
  createdAt: string;
}

export interface CaregiverLink {
  id: number;
  patientId: number;
  patientName: string;
  caregiverName: string;
  caregiverEmail: string;
  relationship: string;
}

export interface HospitalResponse {
  id: number;
  name: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  latitude: number | null;
  longitude: number | null;
  contactPhone: string;
  contactEmail: string;
  description: string;
  logoUrl: string | null;
  status: "PENDING" | "APPROVED" | "REJECTED" | "SUSPENDED";
}
 
export interface HospitalRegisterRequest {
  hospitalName: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  description?: string;
  contactPhone: string;
  adminName: string;
  adminEmail: string;
  adminPassword: string;
  adminPhone: string;
}
 
export interface NearbyHospital {
  id: number;
  name: string;
  address: string;
  city: string;
  state: string;
  description: string;
  logoUrl: string | null;
  distanceKm: number;
}
 
export interface NearbyDoctor {
  id: number;
  doctorName: string;
  specialization: string;
  departmentName: string;
  consultationFee: number;
  averageRating: number | null;
  reviewCount: number;
  hospitalId: number;
  hospitalName: string;
  hospitalCity: string;
  distanceKm: number;
}